		<div class="container">
			
			<h1><?php echo $page['header']; ?></h1>
			
			<?php echo $page['body_formatted']; ?>
			
		</div>