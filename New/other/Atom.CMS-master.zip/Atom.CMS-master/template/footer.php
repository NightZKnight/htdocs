
</div><!-- END wrap -->		

	<footer id="footer">
		
		<div class="container">
			<p>This is my footer.</p>
		</div>
		
	</footer><!-- END footer -->

	<?php if($debug == 1) { include('widgets/debug.php'); } ?>
	
</body>

</html>