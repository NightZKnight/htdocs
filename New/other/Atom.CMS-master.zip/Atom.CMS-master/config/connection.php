<?php

# Database Connection Here...
$dbc = mysqli_connect('localhost', 'dev', 'thepassword', 'atomcms') OR die('Could not connect because: '.mysqli_connect_error());

?>