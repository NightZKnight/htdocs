<?php include('template/header.php'); // Page Header ?>

<?php include('views/'.$view['name'].'.php'); // View Type ?>

<?php include('template/footer.php'); // Page Footer ?>	