<?php 

	include('template/header.php');
	
	include('views/'.$page.'.php'); 
	
	include('template/footer.php');

?>