	</div><!-- END wrap -->		

	<footer id="footer">
	
		<p>This is my footer.</p>
	
	</footer><!-- END footer -->

	<?php if($debug == 1) { include('widgets/debug.php'); } ?>
	
</body>

</html>